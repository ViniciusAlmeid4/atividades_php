<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Exercício 3</title>
</head>
<body>
    <form action="exercicio3.php" method="POST">
        <table>
            <tr>
                <td>Digite a largura</td>
                <td><input type="number" name="largura"></td>
            </tr>
            <tr>
                <td>Digite a Altura</td>
                <td><input type="number" name="altura"></td>
            </tr>
            <tr>
                <td></td>
                <td><input type="submit" name="enviar"></td>
            </tr>
        </table>
    </form>
</body>
</html>