<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
    <form action="exercicio3.php" method="POST" align="center">
        <tr>
            <td><input type="text" name="altura" placeholder="altura"></td>
            <td><input type="text" name="largura" placeholder="largura"></td>
        </tr>
        <br>
        <tr>
            <br>
            <td><input type="submit" name="enviar" value="criar forma"></td>
        </tr>
    </form>
</body>
</html>